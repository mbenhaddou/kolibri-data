Stop Words
==========

List of common stop words in various languages.



Available languages
-------------------
* Arabic
* Bulgarian
* Catalan
* Czech
* Danish
* Dutch
* English
* Finnish
* French
* German
* Hindi
* Hungarian
* Indonesian
* Italian
* Norwegian
* Polish
* Portuguese
* Romanian
* Russian
* Slovak
* Spanish
* Swedish
* Turkish
* Ukrainian
* Vietnamese

Contributing
-----------------
You know how ;)


Programming languages support
-----------------------------

* `Python`: https://github.com/Alir3z4/python-stop-words
* `dotnet`: https://github.com/hklemp/dotnet-stop-words


License
--------
[Attribution 4.0 International (CC BY 4.0)][LICENSE]

[LICENSE]: http://creativecommons.org/licenses/by/4.0/
